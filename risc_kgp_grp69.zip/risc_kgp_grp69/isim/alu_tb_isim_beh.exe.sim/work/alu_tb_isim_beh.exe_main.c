/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000001615630096_1990107506_init();
    work_m_00000000000856526237_0575891062_init();
    work_m_00000000002850734064_2367525917_init();
    work_m_00000000003486060768_0833183191_init();
    work_m_00000000001070640027_4263722963_init();
    work_m_00000000003065592373_3210216067_init();
    work_m_00000000004267438199_2725559894_init();
    work_m_00000000001804930266_2598182923_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000001804930266_2598182923");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
